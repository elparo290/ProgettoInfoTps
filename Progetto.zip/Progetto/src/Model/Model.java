package Model;

/**
 * classe model
 */

public class Model {

	/**
	 * costruttore del model
	 */
	
	public Model()
	{
		
	}
	
}
